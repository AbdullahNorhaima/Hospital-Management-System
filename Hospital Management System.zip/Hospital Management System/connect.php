<?php
$connect = mysqli_connect("localhost: 3306", "root", "", "hospital_management_system");

?>