<?php 
include "connect.php";
session_start();
$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
    header('location:login.php');
 };
 
 if(isset($_GET['logout'])){
   unset($user_ID);
    session_destroy();
    header('location: login.php');
 }

 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Dashboard Page</title>
</head>
<body>
    <div class="container">
<nav>
    <div class="nav-menu">
        <a href=""><h3>HMS</h3> <i class="ri-hospital-fill"></i></a>
    </div>

    <div class="title-page">
        <h3>DashBoard</h3>
    </div>
    <div class="users">

            <div class="profile-users">
            <?php
            
         $query = mysqli_query($connect, "SELECT * FROM `user` WHERE id = '$user_ID'") or die('query failed');
         if(mysqli_num_rows($query) > 0){
            $row = mysqli_fetch_assoc($query);
         }
         if($row['image'] == ''){
            echo '<img src="img/default-profile.jpg" alt="">';
         }else{
           
          echo '<img src="img/'.$row['image'].'" alt="">';
         }
      ?>
        <a href="dashboard.php?logout=<?php echo $user_ID; ?>"><p>Sign out</p></a>
    </div>
    </div>

</nav>
<div class="wrapper-row">


    <div class="data-row">
        <div class="patients-box">

        <a href="patients.php">
        <div class="box"> 
               <div class="total-box">
               
        <p>Patients : <?php 
        $query = mysqli_query($connect, "SELECT * FROM `patients`");
        
        if($row = mysqli_fetch_assoc($query)){
            echo $row = mysqli_num_rows($query);
        }else{
            echo '0';
        }
        ?> </p>
    </div> 
    </div>
        </a>
            

<a href="in.php">
<div class="box">
    <div class="total-box">
        <p>In Patients :
        <?php 
        $query = mysqli_query($connect, "SELECT COUNT(category) AS count FROM `patients` WHERE category = 'InPatient';");
        
        if($row = mysqli_fetch_assoc($query)){
            echo $row['count'];
        }else{
            echo '0';
        }
        ?>        
    </p>
    </div>
</div>
</a>
<a href="out.php">

<div class="box">
    <div class="total-box">
        <p>Out Patients :
        <?php 
        $query = mysqli_query($connect, "SELECT COUNT(category) AS count FROM `patients` WHERE category = 'OutPatient';");
        
        if($row = mysqli_fetch_assoc($query)){
            echo $row['count'];
        }else{
            echo '0';
        }
        ?>        
    
    </p>
    </div>
</div>
</a>

        </div>


         <div class="table-data">
            <table>
            <tr>
                <th>ID</th>
                <th>Patient No.</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Room No.</th>

                <th>Category</th>
                <th>Details</th>
            </tr>
            <?php
            $_count = 1;
            $query = mysqli_query($connect, "SELECT * FROM `patients`");
            if($row_num = mysqli_num_rows($query) == 0){
                $message[] = "No Data";
            }else{
            while($row = mysqli_fetch_assoc($query)){ 
            ?>
            <tr>
                
                <td><?php echo $_count; ?></td>
                <td><?php echo $row['patient_no']; ?> </td>
                <td><?php echo $row['first_name']; ?> </td>
                <td><?php echo $row['last_name']; ?></td>
                <td><?php echo $row['room_no']; ?></td>
                <td><?php echo $row['category']; ?></td>
                <td><a href="view.php?view_ID=<?php echo $row['id'];?>"><i class="ri-eye-fill"></a></i></td>
           </tr>
                <?php 
               $_count++;
            }
                    
                }
                 ?>
            
        </table>
        <h1>
          <?php
             if(isset($message)){
                foreach($message as $message){
                   echo $message;
               }   
               }
          ?>   
        </h1>
       
         </div>
         
        
    </div>

</div>
    </div>
</body>
</html>