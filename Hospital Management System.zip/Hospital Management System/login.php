<?php
include "connect.php";
session_start();

if(isset($_POST['submit'])){

    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $pass = mysqli_real_escape_string($connect, md5($_POST['password']));
 
    $select = mysqli_query($connect, "SELECT * FROM `user` WHERE email = '$email' AND password = '$pass'") or die('query failed');
 
    if(mysqli_num_rows($select) > 0){
       $row = mysqli_fetch_assoc($select);
       $_SESSION['user_id'] = $row['id'];
       header('location: dashboard.php');
    }else{
       $message[] = '<div class="message" style=" width: 100%;
  height: 100%;
  font-size: 18px;
  padding: 10px;
  background: #f4d0d2;
  border: 1px solid #d12f34;">Incorrect Email or Password!</div>';
    }
 
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Register Page</title>
</head>
<body>
    <div class="container-form">
        <form action="" method="post" enctype="multipart/form-data">
             


                <div class="title-name">
                    <h4>Hospi<i class="ri-cross-fill"></i>al</h4>
                </div>
            
            <div class="input-account">
                <div class="input-box">
                    <label for="">Email</label>
                    <input type="email" name="email">
                </div>
                <div class="input-box">
                    <label for="">Password</label>
                    <input type="password" name="password">
                </div>
            </div>
            <div class="btn-form">
                <button type="submit" name="submit">Login</button>
               <a href="register.php"> <button type="button" name="submit">Register</button></a>
            </div>
        </form>
    </div>
</body>
</html>