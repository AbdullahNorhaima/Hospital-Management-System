<?php 
include "connect.php";

session_start();
$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
    header('location:login.php');
 };
 
 if(isset($_GET['logout'])){
   unset($user_ID);
    session_destroy();
    header('location:login.php');
 }
 $patient_no = " ";
 $fname = " ";
 $lname = " ";
 $bith = " ";
 $address = " ";
 $age = " ";
 $phone = " ";
 $room = " ";
 $category = " ";
 $ailment = " ";
 $click = false;

 if(isset($_POST['submit_add'])){
    $patient_no = $_POST['patient_no'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $birth = $_POST['date'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $phone = $_POST['phone'];
    $room = $_POST['room'];
    $category = $_POST['category'];
    $ailment = $_POST['ailment'];
    $sql = "INSERT INTO `patients`(patient_no, first_name, last_name, age, birth, address, phone_no, category, room_no, ailment) VALUES ('$patient_no','$fname','$lname','$age','$birth','$address','$phone','$category','$room','$ailment')";
    if($query = mysqli_query($connect, $sql)){
        $message[] = '<div class="message" style="width: 100%; height: 100%; border: 2px solid green; padding: 13px 10px;" >Registered Patient</div>';
    }else{
        $message[] = "We have problem please check Data!";
    }
 }

 
 if(isset($_GET['ID_Patient'])){
    $_PatientID = $_GET['ID_Patient'];
    $click = true;
    $sql = "SELECT * FROM `patients` WHERE id = '$_PatientID'";
    $query = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($query);
    $patient_no = $row['patient_no'];
    $fname = $row['first_name'];
    $lname = $row['last_name'];
    $age = $row['age'];
    $birth = $row['birth'];
    $address = $row['address'];
    $phone = $row['phone_no'];
    $category = $row['category'];
    $room = $row['room_no'];
    $ailment = $row['ailment'];
 }

 if(isset($_POST['submit_update'])){
    $patient_no = $_POST['patient_no'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $birth = $_POST['date'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $phone = $_POST['phone'];
    $room = $_POST['room'];
    $category = $_POST['category'];
    $ailment = $_POST['ailment'];
    $sql = "UPDATE `patients` SET patient_no = '$patient_no' , first_name = '$fname', last_name = '$lname', age = '$age', birth = '$birth', address = '$address', phone_no = '$phone', category = '$category', room_no = '$room', ailment = '$ailment' WHERE id = '$_PatientID'";
    if($query = mysqli_query($connect, $sql)){
        $message[] = '<div class="message" style="width: 100%; height: 100%; border: 2px solid green; padding: 13px 10px;" >Update Patient Details Successful</div>';
    }else{
        $message[] = "We have problem please check Data!";
    }

}
if(isset($_GET['Delete_Patient'])){
    $_PatientID = $_GET['Delete_Patient'];
    $click = true;
    $sql = "DELETE  FROM `patients` WHERE id = '$_PatientID'";  
   if($query = mysqli_query($connect, $sql)){
     $message[] = '<div class="message" style="width: 100%; height: 100%; border: 2px solid green; padding: 13px 10px;" >Successfully Revome from the list of Patients</div>';
   }else{
    $message[] = "We have problem please check Data!";
   }
    
 }
?>

<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Dashboard Page</title>
</head>
<body>
    <div class="container">
    <nav>
    <div class="nav-menu">
        <a href=""><h3>HMS</h3> <i class="ri-hospital-fill"></i></a>
    </div>

    <div class="title-page">
        <h3>DashBoard</h3>
    </div>
    <div class="users">

            <div class="profile-users">
            <?php
            
         $query = mysqli_query($connect, "SELECT * FROM `user` WHERE id = '$user_ID'") or die('query failed');
         if(mysqli_num_rows($query) > 0){
            $row = mysqli_fetch_assoc($query);
         }
         if($row['image'] == ''){
            echo '<img src="img/default-profile.jpg" alt="">';
         }else{
           
          echo '<img src="img/'.$row['image'].'" alt="">';
         }
      ?>
        <a href="dashboard.php?logout=<?php echo $user_ID; ?>"><p>Sign out</p></a>
    </div>
    </div>

</nav>
<div class="wrapper-row">



    <div class="data-row">
        <div class="back-btn">
            <a href="dashboard.php"> <i class="ri-arrow-go-back-line"></i></a>
        </div> 
<div class="form-patients">
<?php 

   if($click == false):
?>
    <form action="" method="post" enctype="multipart/form-data">
<h3>Register Patients</h3>

<?php
                if(isset($message)){
                    foreach($message as $message){
                       echo $message;
                   }   
                   }
            ?>
        <div class="patient-details">
            <div class="box">
                <label for="">First Name : </label>
                <input type="text" name="fname">
            </div>
            <div class="box">
                <label for="">Last Name : </label>
                <input type="text" name="lname">
            </div>

        </div>
        <div class="patient-details">
            <div class="box">
                <label for="">Age : </label>
                <input type="number" name="age">
            </div>
            <div class="box">
                <label for="">Birth Date : </label>
                <input type="date" name="date">
            </div>
            <div class="box">
                <label for="">Address : </label>
                <textarea name="address" id=""></textarea>
            </div>
        </div>

        <div class="patient-details">
            <div class="box">
                <label for="">Phone No. : </label>
                <input type="number" name="phone">
            </div>
            <div class="box">
                <label for="">Patient No. : </label>
                <input type="text" name="patient_no">
            </div>
            <div class="box">
                <label for="">Room No. : </label>
                <input type="text" name="room">
            </div>
        </div>

        <div class="patient-details">

            <div class="box">
                <label for="">Ailment. : </label>
                <input type="text" name="ailment">
            </div>
            <div class="box">
                <label for="">Category : </label>
                <select name="category" id="cars">
                    <option value=" "></option>
                    <option value="InPatient">InPatient</option>
                    <option value="OutPatient">OutPatient</option>
                  </select>
            </div>
        </div>
        <div class="btn-box">
            <button type="submit" name="submit_add">Submit</button>
        </div>
    </form>
    <?php 
else:?>
    <form action="" method="post" enctype="multipart/form-data">
<h3>Update Patients Details</h3>
<?php
                if(isset($message)){
                    foreach($message as $message){
                       echo $message;
                   }   
                   }
            ?>
        <div class="patient-details">
            <div class="box">
                <label for="">First Name : </label>
                <input type="text" name="fname" value="<?php echo $fname; ?>">
            </div>
            <div class="box">
                <label for="">Last Name : </label>
                <input type="text" name="lname" value="<?php echo $lname; ?>">
            </div>

        </div>
        <div class="patient-details">
            <div class="box">
                <label for="">Age : </label>
                <input type="number" name="age" value="<?php echo $age; ?>">
            </div>
            <div class="box">
                <label for="">Birth Date : </label>
                <input type="date" name="date" value="<?php echo $date; ?>">
            </div>
            <div class="box">
                <label for="">Address : </label>
                <textarea name="address" id=""><?php echo $address; ?></textarea>
            </div>
        </div>

        <div class="patient-details">
            <div class="box">
                <label for="">Phone No. : </label>
                <input type="number" name="phone" value="<?php echo $phone; ?>">
            </div>
            <div class="box">
                <label for="">Patient No. : </label>
                <input type="text" name="patient_no" value="<?php echo $patient_no; ?>">
            </div>
            <div class="box">
                <label for="">Room No. : </label>
                <input type="text" name="room" value="<?php echo $room; ?>">
            </div>
        </div>

        <div class="patient-details">

            <div class="box">
                <label for="">Ailment. : </label>
                <input type="text" name="ailment" value="<?php echo $ailment; ?>">
            </div>
            <div class="box">
                <label for="">Category : </label>
                <select name="category" id="cars">
                    <option value=" "><?php echo $category; ?></option>
                    <option value="InPatient">InPatient</option>
                    <option value="OutPatient">OutPatient</option>
                  </select>
            </div>
        </div>
        <div class="btn-box">
            <button type="submit" name="submit_update">Update</button>
        </div>
    </form>

<?php 
endif?>
</div>   



         <div class="table-data">
            <table>
            <tr>
                <th>ID</th>
                <th>Patient No.</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Room No.</th>

                <th>Category</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            <?php
            $_count = 1;
            $query = mysqli_query($connect, "SELECT * FROM `patients`");
            while($row = mysqli_fetch_assoc($query)){ 
            ?>
            <tr>
                
                <td><?php echo $_count; ?></td>
                <td><?php echo $row['patient_no']; ?> </td>
                <td><?php echo $row['first_name']; ?> </td>
                <td><?php echo $row['last_name']; ?></td>
                <td><?php echo $row['room_no']; ?></td>
                <td><?php echo $row['category']; ?></td>
                <td><a href="patients.php?ID_Patient=<?php echo $row['id'];?>"><i class="ri-file-edit-line"></a></i></td>
                <td><a href="patients.php?Delete_Patient=<?php echo $row['id'];?>"><i class="ri-delete-bin-6-line"></i></a></td>
           </tr>
                <?php 
               $_count++;
            } 
                 ?>
            
        </table>
        <h1>
          <?php
           
          ?>   
        </h1>
        
    </div>

</div>
    </div>

</body>
</html>


