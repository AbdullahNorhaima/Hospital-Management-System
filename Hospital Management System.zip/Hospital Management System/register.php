<?php
include 'connect.php';
if(isset($_POST['btn-submit'])){


    $fname = mysqli_real_escape_string($connect, $_POST['fname']);
    $lname = mysqli_real_escape_string($connect, $_POST['lname']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $pass = mysqli_real_escape_string($connect, md5($_POST['npassword']));
    $cpass = mysqli_real_escape_string($connect, md5($_POST['cpassword']));
 

$image = $_FILES['user-profile']['name'];
$image_size = $_FILES['user-profile']['size'];
$image_temp_name = $_FILES['user-profile']['tmp_name'];
$image_folder = 'img/'. $image;


    if($pass != $cpass){
       $message[] = '<div class="message" style=" width: 100%;
  height: 100%;
  font-size: 18px;
  padding: 10px;
  background: #f4d0d2;
  border: 1px solid #d12f34;"> Confirm  password is not matched your new password</div>';
    }else{
    $insert = mysqli_query($connect, "INSERT INTO `user`(fname, lname, email, password, image) VALUES('$fname', '$lname','$email', '$pass', '$image')") or die(mysqli_error($connect));
    if($insert){
        $message[] = '<div class="message" style="border: 2px solid green; padding: 13px; margin-top: 20px; background-color: #a9dcb5; color: #fff;"> Registered Success </div>';
     }else{
        $message[] = '<div class="message" style=" width: 100%;
  height: 100%;
  font-size: 18px;
  padding: 10px;
  background: #f4d0d2;
  border: 1px solid #d12f34;"> Please Check your Data! </div>';
     }
  }
}

 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Register Page</title>
</head>
<body>
    <div class="container-form">
        <form action="" method="post" enctype="multipart/form-data">
             <h3>Register </h3>
             <div class="title-name">
                <h4>Hospi<i class="ri-cross-fill"></i>al</h4>
            </div>
            <?php
                if(isset($message)){
                    foreach($message as $message){
                       echo $message;
                   }   
                   }
            ?>
            <div class="image-box">
                <img src="img/default-profile.jpg" alt="">

                <div class="img-box" id="box">
                    <input type="file" name="user-profile" accept="image/jpg, image/jpeg, image/png">
                    <i class="ri-camera-fill"></i>
                 </div>
            </div>
            <div class="input-name">
                <div class="input-box">
                    <label for="">First Name</label>
                    <input type="text" name="fname">
                </div>
                <div class="input-box">
                    <label for="">Last Name</label>
                    <input type="text" name="lname">
                </div>
                
            </div>
            <div class="input-account">
                <div class="input-box">
                    <label for="">Email</label>
                    <input type="email" name="email">
                </div>
                <div class="input-box">
                    <label for="">New Password</label>
                    <input type="password" name="npassword">
                </div>
                <div class="input-box">
                    <label for="">Confirm Password</label>
                    <input type="password" name="cpassword">
                </div>
            </div>
            <div class="btn-form">
               <a href="login.php"><button type="button" name="button">Login</button></a> 
                <button type="submit" name="btn-submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>