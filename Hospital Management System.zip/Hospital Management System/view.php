<?php 
include "connect.php";
session_start();
$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
    header('location:login.php');
 };
 
 if(isset($_GET['logout'])){
   unset($user_ID);
    session_destroy();
    header('location:login.php');
 }


if(isset($_GET['view_ID'])){
    $_ID = $_GET['view_ID'];
    $sql = "SELECT * FROM `patients` WHERE id = $_ID";
    $query = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($query);
    $_SESSION['ID'] = $row['id'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Profile Patient</title>
</head>
<body>
    
<div class="patients" id="row">
<?php 
$_PatientID = $_SESSION['ID'];
$query = mysqli_query($connect, "SELECT * FROM `patients` WHERE id = '$_PatientID'");
$row = mysqli_fetch_assoc($query);
?>
      

    <div class="details-patient">
        <a href="dashboard.php">
        <i class="ri-close-circle-fill"></i>
     </a>  
        <div class="patient-box">
           <h3>Patient Profile </h3> 
            <img src="img/default-profile.jpg" alt="">
            <div class="details">
                <p><?php echo $row['first_name'].' '. $row['last_name']; ?></p>
                <ul>
                    <li>Age : <?php echo $row['age']; ?></li>
                    <li>Birth Date : <?php echo $row['birth']; ?></li>
                    <li>Address : <?php echo $row['address']; ?></li>
                    <li>Phone No. : <?php echo $row['phone_no']; ?></li>
                    
                    <li>Patient No. : <?php echo $row['patient_no']; ?></li>
                    <li>Category : <?php echo $row['category']; ?></li>
                    <li>Room No. : <?php echo $row['room_no']; ?></li>
                    <li>Patient Ailment : <?php echo $row['ailment']; ?></li>
                    
                </ul>
            </div>
        </div>
    </div>
    
</div>
</body>
</html>